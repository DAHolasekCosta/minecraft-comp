For solutions to common problems, compatibility information, and more: https://continuum.graphics/faq/
For support when the above does not suffice: https://continuum.graphics/contact-us/

️ 2024 Continuum Graphics LLC.
Do Not Redistribute.